/**
 * 
 */
package com.sample.assignment.file;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author sonal
 *
 */
@SpringBootApplication
public class FileProcessStarter {

	/**
	 * @param args
	 */
	public static void main(String... args) {
		SpringApplication.run(FileProcessStarter.class, args);
	}

}
